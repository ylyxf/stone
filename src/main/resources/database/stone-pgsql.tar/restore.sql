--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.st_role_user DROP CONSTRAINT st_role_user_user_id_fkey;
ALTER TABLE ONLY public.st_role_user DROP CONSTRAINT st_role_user_role_id_fkey;
ALTER TABLE ONLY public.st_role_operation DROP CONSTRAINT st_role_operation_fkey;
ALTER TABLE ONLY public.st_group_user DROP CONSTRAINT st_group_user_group_id_fkey;
ALTER TABLE ONLY public.st_group_user DROP CONSTRAINT st_group_re_user_user_id_fkey;
ALTER TABLE ONLY public.st_dict_item DROP CONSTRAINT st_dict_item_dict_code_fkey;
ALTER TABLE ONLY public.st_enum_value DROP CONSTRAINT fk_st_enum_reference_st_data_;
ALTER TABLE ONLY public.st_data_filter_item DROP CONSTRAINT fk_st_data_reference_st_data_;
ALTER TABLE ONLY public.st_user DROP CONSTRAINT st_user_pkey;
ALTER TABLE ONLY public.st_role_user DROP CONSTRAINT st_role_user_pkey;
ALTER TABLE ONLY public.st_role DROP CONSTRAINT st_role_pkey;
ALTER TABLE ONLY public.st_role_operation DROP CONSTRAINT st_role_operation_pkey;
ALTER TABLE ONLY public.st_group_user DROP CONSTRAINT st_group_re_user_pkey;
ALTER TABLE ONLY public.st_group DROP CONSTRAINT st_group_pkey;
ALTER TABLE ONLY public.st_dict DROP CONSTRAINT st_dict_pkey;
ALTER TABLE ONLY public.st_dict_item DROP CONSTRAINT st_dict_item_pkey;
ALTER TABLE ONLY public.st_config DROP CONSTRAINT st_config_pkey;
ALTER TABLE ONLY public.st_enum_value DROP CONSTRAINT pk_st_enum_value;
ALTER TABLE ONLY public.st_data_filter_item DROP CONSTRAINT pk_st_data_filter_item;
ALTER TABLE ONLY public.st_data_filter DROP CONSTRAINT pk_st_data_filter;
ALTER TABLE public.st_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.st_role_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.st_role_operation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.st_role ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.st_group_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.st_group ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.st_enum_value ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.st_dict_item ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.st_data_filter_item ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.st_data_filter ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.st_user_id_seq;
DROP TABLE public.st_user;
DROP SEQUENCE public.st_role_user_id_seq;
DROP TABLE public.st_role_user;
DROP SEQUENCE public.st_role_operation_id_seq;
DROP TABLE public.st_role_operation;
DROP SEQUENCE public.st_role_id_seq;
DROP TABLE public.st_role;
DROP SEQUENCE public.st_group_user_id_seq;
DROP TABLE public.st_group_user;
DROP SEQUENCE public.st_group_id_seq;
DROP TABLE public.st_group;
DROP SEQUENCE public.st_enum_value_id_seq;
DROP TABLE public.st_enum_value;
DROP SEQUENCE public.st_dict_item_id_seq;
DROP TABLE public.st_dict_item;
DROP TABLE public.st_dict;
DROP SEQUENCE public.st_data_filter_item_id_seq;
DROP TABLE public.st_data_filter_item;
DROP SEQUENCE public.st_data_filter_id_seq;
DROP TABLE public.st_data_filter;
DROP TABLE public.st_config;
DROP FUNCTION public.get_path(current_id integer, table_name character varying);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: get_path(integer, character varying); Type: FUNCTION; Schema: public; Owner: stone
--

CREATE FUNCTION get_path(current_id integer, table_name character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
	v_sqlstring varchar(240); 
    v_result character varying;
    v_current_name character varying;
    v_parent_id integer;
BEGIN
	v_sqlstring :=  'SELECT parent_id  FROM ' ||table_name ||' WHERE id ='||current_id||';';
    EXECUTE v_sqlstring into v_parent_id; 
        IF v_parent_id is not NULL THEN
        	v_sqlstring :=  'SELECT name  FROM ' ||table_name ||' WHERE id ='||current_id||';';
        	EXECUTE v_sqlstring into v_current_name; 
            v_result := get_path(v_parent_id,table_name) || '/' || v_current_name;
        ELSE
            RETURN '';
        END IF;
    RETURN v_result;
END;
$$;


ALTER FUNCTION public.get_path(current_id integer, table_name character varying) OWNER TO stone;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: st_config; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_config (
    code character varying(120) NOT NULL,
    class_code character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE st_config OWNER TO stone;

--
-- Name: COLUMN st_config.code; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_config.code IS '类的属性名';


--
-- Name: COLUMN st_config.value; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_config.value IS '值';


--
-- Name: st_data_filter; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_data_filter (
    id integer NOT NULL,
    name character varying(64),
    remark character varying(256)
);


ALTER TABLE st_data_filter OWNER TO stone;

--
-- Name: COLUMN st_data_filter.id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter.id IS '数据过滤器';


--
-- Name: COLUMN st_data_filter.name; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter.name IS '名称';


--
-- Name: COLUMN st_data_filter.remark; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter.remark IS '备注';


--
-- Name: st_data_filter_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_data_filter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_data_filter_id_seq OWNER TO stone;

--
-- Name: st_data_filter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_data_filter_id_seq OWNED BY st_data_filter.id;


--
-- Name: st_data_filter_item; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_data_filter_item (
    id integer NOT NULL,
    prefix_code character varying(5),
    column_code character varying(64),
    compare_symbol character varying(64),
    first_value character varying(2000),
    second_value character varying(2000),
    suffix_code character varying(5),
    data_type character varying(128),
    type character varying(16),
    sort_no integer,
    data_filter_id integer
);


ALTER TABLE st_data_filter_item OWNER TO stone;

--
-- Name: COLUMN st_data_filter_item.id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.id IS '表达式id';


--
-- Name: COLUMN st_data_filter_item.prefix_code; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.prefix_code IS '前缀';


--
-- Name: COLUMN st_data_filter_item.column_code; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.column_code IS '列编码';


--
-- Name: COLUMN st_data_filter_item.compare_symbol; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.compare_symbol IS '操作符';


--
-- Name: COLUMN st_data_filter_item.first_value; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.first_value IS '第一值';


--
-- Name: COLUMN st_data_filter_item.second_value; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.second_value IS '第二值';


--
-- Name: COLUMN st_data_filter_item.suffix_code; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.suffix_code IS '后缀';


--
-- Name: COLUMN st_data_filter_item.data_type; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.data_type IS '数值类型';


--
-- Name: COLUMN st_data_filter_item.type; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.type IS '表达式类型';


--
-- Name: COLUMN st_data_filter_item.sort_no; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.sort_no IS '序号';


--
-- Name: COLUMN st_data_filter_item.data_filter_id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_data_filter_item.data_filter_id IS '数据过滤器';


--
-- Name: st_data_filter_item_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_data_filter_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_data_filter_item_id_seq OWNER TO stone;

--
-- Name: st_data_filter_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_data_filter_item_id_seq OWNED BY st_data_filter_item.id;


--
-- Name: st_dict; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_dict (
    code character varying(64) NOT NULL,
    name character varying(20),
    sort_no integer,
    remark character varying(100)
);


ALTER TABLE st_dict OWNER TO stone;

--
-- Name: st_dict_item; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_dict_item (
    id integer NOT NULL,
    label character varying(20),
    value character varying(20),
    sort_no integer,
    remark character varying(50),
    dict_code character varying(64)
);


ALTER TABLE st_dict_item OWNER TO stone;

--
-- Name: st_dict_item_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_dict_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_dict_item_id_seq OWNER TO stone;

--
-- Name: st_dict_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_dict_item_id_seq OWNED BY st_dict_item.id;


--
-- Name: st_enum_value; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_enum_value (
    id integer NOT NULL,
    data_filter_item_id integer,
    data_value character varying(64)
);


ALTER TABLE st_enum_value OWNER TO stone;

--
-- Name: COLUMN st_enum_value.data_filter_item_id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_enum_value.data_filter_item_id IS '表达式id';


--
-- Name: st_enum_value_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_enum_value_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_enum_value_id_seq OWNER TO stone;

--
-- Name: st_enum_value_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_enum_value_id_seq OWNED BY st_enum_value.id;


--
-- Name: st_group; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_group (
    id integer NOT NULL,
    parent_id integer,
    code character varying(20),
    name character varying(64),
    is_leaf boolean,
    sort_no integer,
    type character varying(20),
    logic_deleted boolean
);


ALTER TABLE st_group OWNER TO stone;

--
-- Name: COLUMN st_group.id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group.id IS '群组id';


--
-- Name: COLUMN st_group.parent_id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group.parent_id IS '父群组id';


--
-- Name: COLUMN st_group.code; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group.code IS '群组编码';


--
-- Name: COLUMN st_group.name; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group.name IS '群组名称';


--
-- Name: COLUMN st_group.is_leaf; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group.is_leaf IS '是否叶子节点';


--
-- Name: COLUMN st_group.sort_no; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group.sort_no IS '序号';


--
-- Name: COLUMN st_group.type; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group.type IS '组织类型';


--
-- Name: COLUMN st_group.logic_deleted; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group.logic_deleted IS '逻辑删除';


--
-- Name: st_group_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_group_id_seq OWNER TO stone;

--
-- Name: st_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_group_id_seq OWNED BY st_group.id;


--
-- Name: st_group_user; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_group_user (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    is_default boolean DEFAULT false,
    sort_no integer
);


ALTER TABLE st_group_user OWNER TO stone;

--
-- Name: COLUMN st_group_user.id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group_user.id IS 'id';


--
-- Name: COLUMN st_group_user.user_id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group_user.user_id IS '用户Id';


--
-- Name: COLUMN st_group_user.group_id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group_user.group_id IS '群组id';


--
-- Name: COLUMN st_group_user.is_default; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group_user.is_default IS '是否默认群组';


--
-- Name: COLUMN st_group_user.sort_no; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_group_user.sort_no IS '序号';


--
-- Name: st_group_user_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_group_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_group_user_id_seq OWNER TO stone;

--
-- Name: st_group_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_group_user_id_seq OWNED BY st_group_user.id;


--
-- Name: st_role; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_role (
    id integer NOT NULL,
    name character varying(64),
    enabled boolean,
    sort_no integer
);


ALTER TABLE st_role OWNER TO stone;

--
-- Name: COLUMN st_role.id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role.id IS '角色Id';


--
-- Name: COLUMN st_role.name; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role.name IS '角色名称';


--
-- Name: COLUMN st_role.enabled; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role.enabled IS '是否启用';


--
-- Name: COLUMN st_role.sort_no; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role.sort_no IS '序号';


--
-- Name: st_role_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_role_id_seq OWNER TO stone;

--
-- Name: st_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_role_id_seq OWNED BY st_role.id;


--
-- Name: st_role_operation; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_role_operation (
    id integer NOT NULL,
    role_id integer NOT NULL,
    operation_code character varying(100),
    data_filter_id integer
);


ALTER TABLE st_role_operation OWNER TO stone;

--
-- Name: COLUMN st_role_operation.id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role_operation.id IS '主键';


--
-- Name: COLUMN st_role_operation.role_id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role_operation.role_id IS '角色Id';


--
-- Name: COLUMN st_role_operation.operation_code; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role_operation.operation_code IS '操作代码';


--
-- Name: COLUMN st_role_operation.data_filter_id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role_operation.data_filter_id IS '数据集合Id';


--
-- Name: st_role_operation_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_role_operation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_role_operation_id_seq OWNER TO stone;

--
-- Name: st_role_operation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_role_operation_id_seq OWNED BY st_role_operation.id;


--
-- Name: st_role_user; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_role_user (
    id integer NOT NULL,
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE st_role_user OWNER TO stone;

--
-- Name: COLUMN st_role_user.user_id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role_user.user_id IS '用户Id';


--
-- Name: COLUMN st_role_user.role_id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_role_user.role_id IS '角色Id';


--
-- Name: st_role_user_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_role_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_role_user_id_seq OWNER TO stone;

--
-- Name: st_role_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_role_user_id_seq OWNED BY st_role_user.id;


--
-- Name: st_user; Type: TABLE; Schema: public; Owner: stone
--

CREATE TABLE st_user (
    id integer NOT NULL,
    account character varying(64) NOT NULL,
    password character varying(256),
    name character varying(64),
    type character varying(16),
    phone character varying(64),
    email character varying(64),
    enabled boolean,
    logic_deleted boolean,
    mobile_phone character varying(16)
);


ALTER TABLE st_user OWNER TO stone;

--
-- Name: COLUMN st_user.id; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_user.id IS '用户Id';


--
-- Name: COLUMN st_user.account; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_user.account IS '账户';


--
-- Name: COLUMN st_user.password; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_user.password IS '密码';


--
-- Name: COLUMN st_user.name; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_user.name IS '用户名';


--
-- Name: COLUMN st_user.phone; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_user.phone IS '手机号码';


--
-- Name: COLUMN st_user.email; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_user.email IS '电子邮箱';


--
-- Name: COLUMN st_user.enabled; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_user.enabled IS '是否可用';


--
-- Name: COLUMN st_user.logic_deleted; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_user.logic_deleted IS '是否删除';


--
-- Name: COLUMN st_user.mobile_phone; Type: COMMENT; Schema: public; Owner: stone
--

COMMENT ON COLUMN st_user.mobile_phone IS '手机号码';


--
-- Name: st_user_id_seq; Type: SEQUENCE; Schema: public; Owner: stone
--

CREATE SEQUENCE st_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE st_user_id_seq OWNER TO stone;

--
-- Name: st_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: stone
--

ALTER SEQUENCE st_user_id_seq OWNED BY st_user.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_data_filter ALTER COLUMN id SET DEFAULT nextval('st_data_filter_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_data_filter_item ALTER COLUMN id SET DEFAULT nextval('st_data_filter_item_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_dict_item ALTER COLUMN id SET DEFAULT nextval('st_dict_item_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_enum_value ALTER COLUMN id SET DEFAULT nextval('st_enum_value_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_group ALTER COLUMN id SET DEFAULT nextval('st_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_group_user ALTER COLUMN id SET DEFAULT nextval('st_group_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_role ALTER COLUMN id SET DEFAULT nextval('st_role_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_role_operation ALTER COLUMN id SET DEFAULT nextval('st_role_operation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_role_user ALTER COLUMN id SET DEFAULT nextval('st_role_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_user ALTER COLUMN id SET DEFAULT nextval('st_user_id_seq'::regclass);


--
-- Data for Name: st_config; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_config (code, class_code, value) FROM stdin;
\.
COPY st_config (code, class_code, value) FROM '$$PATH$$/2204.dat';

--
-- Data for Name: st_data_filter; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_data_filter (id, name, remark) FROM stdin;
\.
COPY st_data_filter (id, name, remark) FROM '$$PATH$$/2206.dat';

--
-- Name: st_data_filter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_data_filter_id_seq', 1, false);


--
-- Data for Name: st_data_filter_item; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_data_filter_item (id, prefix_code, column_code, compare_symbol, first_value, second_value, suffix_code, data_type, type, sort_no, data_filter_id) FROM stdin;
\.
COPY st_data_filter_item (id, prefix_code, column_code, compare_symbol, first_value, second_value, suffix_code, data_type, type, sort_no, data_filter_id) FROM '$$PATH$$/2208.dat';

--
-- Name: st_data_filter_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_data_filter_item_id_seq', 1, false);


--
-- Data for Name: st_dict; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_dict (code, name, sort_no, remark) FROM stdin;
\.
COPY st_dict (code, name, sort_no, remark) FROM '$$PATH$$/2209.dat';

--
-- Data for Name: st_dict_item; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_dict_item (id, label, value, sort_no, remark, dict_code) FROM stdin;
\.
COPY st_dict_item (id, label, value, sort_no, remark, dict_code) FROM '$$PATH$$/2211.dat';

--
-- Name: st_dict_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_dict_item_id_seq', 1, false);


--
-- Data for Name: st_enum_value; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_enum_value (id, data_filter_item_id, data_value) FROM stdin;
\.
COPY st_enum_value (id, data_filter_item_id, data_value) FROM '$$PATH$$/2213.dat';

--
-- Name: st_enum_value_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_enum_value_id_seq', 1, false);


--
-- Data for Name: st_group; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_group (id, parent_id, code, name, is_leaf, sort_no, type, logic_deleted) FROM stdin;
\.
COPY st_group (id, parent_id, code, name, is_leaf, sort_no, type, logic_deleted) FROM '$$PATH$$/2215.dat';

--
-- Name: st_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_group_id_seq', 1, false);


--
-- Data for Name: st_group_user; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_group_user (id, user_id, group_id, is_default, sort_no) FROM stdin;
\.
COPY st_group_user (id, user_id, group_id, is_default, sort_no) FROM '$$PATH$$/2217.dat';

--
-- Name: st_group_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_group_user_id_seq', 1, false);


--
-- Data for Name: st_role; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_role (id, name, enabled, sort_no) FROM stdin;
\.
COPY st_role (id, name, enabled, sort_no) FROM '$$PATH$$/2219.dat';

--
-- Name: st_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_role_id_seq', 1, false);


--
-- Data for Name: st_role_operation; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_role_operation (id, role_id, operation_code, data_filter_id) FROM stdin;
\.
COPY st_role_operation (id, role_id, operation_code, data_filter_id) FROM '$$PATH$$/2221.dat';

--
-- Name: st_role_operation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_role_operation_id_seq', 1, false);


--
-- Data for Name: st_role_user; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_role_user (id, user_id, role_id) FROM stdin;
\.
COPY st_role_user (id, user_id, role_id) FROM '$$PATH$$/2223.dat';

--
-- Name: st_role_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_role_user_id_seq', 1, false);


--
-- Data for Name: st_user; Type: TABLE DATA; Schema: public; Owner: stone
--

COPY st_user (id, account, password, name, type, phone, email, enabled, logic_deleted, mobile_phone) FROM stdin;
\.
COPY st_user (id, account, password, name, type, phone, email, enabled, logic_deleted, mobile_phone) FROM '$$PATH$$/2225.dat';

--
-- Name: st_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: stone
--

SELECT pg_catalog.setval('st_user_id_seq', 1, false);


--
-- Name: pk_st_data_filter; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_data_filter
    ADD CONSTRAINT pk_st_data_filter PRIMARY KEY (id);


--
-- Name: pk_st_data_filter_item; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_data_filter_item
    ADD CONSTRAINT pk_st_data_filter_item PRIMARY KEY (id);


--
-- Name: pk_st_enum_value; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_enum_value
    ADD CONSTRAINT pk_st_enum_value PRIMARY KEY (id);


--
-- Name: st_config_pkey; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_config
    ADD CONSTRAINT st_config_pkey PRIMARY KEY (code, class_code);


--
-- Name: st_dict_item_pkey; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_dict_item
    ADD CONSTRAINT st_dict_item_pkey PRIMARY KEY (id);


--
-- Name: st_dict_pkey; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_dict
    ADD CONSTRAINT st_dict_pkey PRIMARY KEY (code);


--
-- Name: st_group_pkey; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_group
    ADD CONSTRAINT st_group_pkey PRIMARY KEY (id);


--
-- Name: st_group_re_user_pkey; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_group_user
    ADD CONSTRAINT st_group_re_user_pkey PRIMARY KEY (id);


--
-- Name: st_role_operation_pkey; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_role_operation
    ADD CONSTRAINT st_role_operation_pkey PRIMARY KEY (id);


--
-- Name: st_role_pkey; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_role
    ADD CONSTRAINT st_role_pkey PRIMARY KEY (id);


--
-- Name: st_role_user_pkey; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_role_user
    ADD CONSTRAINT st_role_user_pkey PRIMARY KEY (id);


--
-- Name: st_user_pkey; Type: CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_user
    ADD CONSTRAINT st_user_pkey PRIMARY KEY (id);


--
-- Name: fk_st_data_reference_st_data_; Type: FK CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_data_filter_item
    ADD CONSTRAINT fk_st_data_reference_st_data_ FOREIGN KEY (data_filter_id) REFERENCES st_data_filter(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: fk_st_enum_reference_st_data_; Type: FK CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_enum_value
    ADD CONSTRAINT fk_st_enum_reference_st_data_ FOREIGN KEY (data_filter_item_id) REFERENCES st_data_filter_item(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: st_dict_item_dict_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_dict_item
    ADD CONSTRAINT st_dict_item_dict_code_fkey FOREIGN KEY (dict_code) REFERENCES st_dict(code) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: st_group_re_user_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_group_user
    ADD CONSTRAINT st_group_re_user_user_id_fkey FOREIGN KEY (user_id) REFERENCES st_user(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: st_group_user_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_group_user
    ADD CONSTRAINT st_group_user_group_id_fkey FOREIGN KEY (group_id) REFERENCES st_group(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: st_role_operation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_role_operation
    ADD CONSTRAINT st_role_operation_fkey FOREIGN KEY (role_id) REFERENCES st_role(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: st_role_user_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_role_user
    ADD CONSTRAINT st_role_user_role_id_fkey FOREIGN KEY (role_id) REFERENCES st_role(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: st_role_user_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: stone
--

ALTER TABLE ONLY st_role_user
    ADD CONSTRAINT st_role_user_user_id_fkey FOREIGN KEY (user_id) REFERENCES st_user(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

